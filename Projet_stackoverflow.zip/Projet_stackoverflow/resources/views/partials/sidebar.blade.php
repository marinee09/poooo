<div class="widget widget_stats">
    <h3 class="widget_title">Stats</h3>
    <div class="ul_list ul_list-icon-ok">
        <ul>
            <li><i class="icon-question-sign"></i>Questions ( <span>20</span> )</li>
            <li><i class="icon-comment"></i>Answers ( <span>50</span> )</li>
        </ul>
    </div>
</div>

{{--<div class="widget widget_tag_cloud">--}}
    {{--<h3 class="widget_title">Tags</h3>--}}
    {{--<a href="#">projects</a>--}}
    {{--<a href="#">Portfolio</a>--}}
    {{--<a href="#">Wordpress</a>--}}
    {{--<a href="#">Html</a>--}}
    {{--<a href="#">Css</a>--}}
    {{--<a href="#">jQuery</a>--}}
    {{--<a href="#">2code</a>--}}
    {{--<a href="#">vbegy</a>--}}
{{--</div>--}}
