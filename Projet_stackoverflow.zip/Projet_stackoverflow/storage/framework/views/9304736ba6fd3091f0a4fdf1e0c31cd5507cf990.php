<!doctype html>

<html lang="<?php echo e(app()->getLocale()); ?>">

    <head>



        <title>Ask me – <?php echo $__env->yieldContent('title'); ?></title>



        <?php echo $__env->make('partials/head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>



    </head>

    <body>



        <div class="loader"><div class="loader_html"></div></div>



        <div id="wrap" class="grid_1200">



            

            <?php echo $__env->make('partials/header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>



            <section class="container main-content margin_t_50">

                <div class="row">

                    <div class="col-md-12">

                        <?php echo $__env->yieldContent('content'); ?>

                    </div>

                </div>

            </section><!-- End container -->



            <?php echo $__env->make('partials/footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        </div><!-- End wrap -->



        <div class="go-up"><i class="icon-chevron-up"></i></div>



        <!-- js -->

        <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>

        <script src="<?php echo e(asset('js/jquery-ui-1.10.3.custom.min.js')); ?>"></script>

        <script src="<?php echo e(asset('js/jquery.easing.1.3.min.js')); ?>"></script>

        <script src="<?php echo e(asset('js/html5.js')); ?>"></script>

        <script src="<?php echo e(asset('js/twitter/jquery.tweet.js')); ?>"></script>

        <script src="<?php echo e(asset('js/jflickrfeed.min.js')); ?>"></script>

        <script src="<?php echo e(asset('js/jquery.inview.min.js')); ?>"></script>

        <script src="<?php echo e(asset('js/jquery.tipsy.js')); ?>"></script>

        <script src="<?php echo e(asset('js/tabs.js')); ?>"></script>

        <script src="<?php echo e(asset('js/jquery.flexslider.js')); ?>"></script>

        <script src="<?php echo e(asset('js/jquery.prettyPhoto.js')); ?>"></script>

        <script src="<?php echo e(asset('js/jquery.carouFredSel-6.2.1-packed.js')); ?>"></script>

        <script src="<?php echo e(asset('js/jquery.scrollTo.js')); ?>"></script>

        <script src="<?php echo e(asset('js/jquery.nav.js')); ?>"></script>

        <script src="<?php echo e(asset('js/tags.js')); ?>"></script>

        <script src="<?php echo e(asset('js/jquery.bxslider.min.js')); ?>"></script>

        <script src="<?php echo e(asset('js/custom.js')); ?>"></script>

        <!-- End js -->

    </body>

</html>