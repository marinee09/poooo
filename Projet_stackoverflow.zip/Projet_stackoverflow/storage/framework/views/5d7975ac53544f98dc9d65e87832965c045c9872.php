<div class="widget widget_stats">
    <h3 class="widget_title">Stats</h3>
    <div class="ul_list ul_list-icon-ok">
        <ul>
            <li><i class="icon-question-sign"></i>Questions ( <span>20</span> )</li>
            <li><i class="icon-comment"></i>Answers ( <span>50</span> )</li>
        </ul>
    </div>
</div>


    
    
    
    
    
    
    
    
    

