<?php $__env->startSection('title', 'Questions/réponses pour les promotions Simplon'); ?>


<?php $__env->startSection('search-form'); ?>
    <?php echo $__env->make('partials/search', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="tabs-warp question-tab">
        
            
            
            
            
        
        <div class="tab-inner-warp">
            <div class="tab-inner">
                <article class="question question-type-normal">
                    <h2>
                        <a href="<?php echo e(url('/question')); ?>">Vivamus at elit quis urna adipiscing iaculis.</a>
                    </h2>
                    <div class="question-author-date">
                        Asked <em>4 mins ago</em> by <a href="#">Peter</a>
                    </div>
                    <div class="question-inner">
                        <div class="clearfix"></div>
                        <p class="question-desc">Duis dapibus aliquam mi, eget euismod sem scelerisque ut. Vivamus at elit quis urna adipiscing iaculis. Curabitur vitae velit in neque dictum blandit. Proin in iaculis neque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Curabitur vitae velit in neque dictum blandit.</p>
                        
                            
                        
                        
                        
                        
                            
                        
                        <div class="clearfix"></div>
                    </div>
                </article>
                <article class="question question-type-normal">
                    <h2>
                        <a href="<?php echo e(url('/question')); ?>">Vivamus at elit quis urna adipiscing iaculis.</a>
                    </h2>
                    <div class="question-author-date">
                        Asked <em>4 mins ago</em> by <a href="#">Peter</a>
                    </div>
                    <div class="question-inner">
                        <div class="clearfix"></div>
                        <p class="question-desc">Duis dapibus aliquam mi, eget euismod sem scelerisque ut. Vivamus at elit quis urna adipiscing iaculis. Curabitur vitae velit in neque dictum blandit. Proin in iaculis neque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Curabitur vitae velit in neque dictum blandit.</p>
                        
                            
                        
                        
                        
                        
                            
                        
                        <div class="clearfix"></div>
                    </div>
                </article>
                <article class="question question-type-normal">
                    <h2>
                        <a href="<?php echo e(url('/question')); ?>">Vivamus at elit quis urna adipiscing iaculis.</a>
                    </h2>
                    <div class="question-author-date">
                        Asked <em>4 mins ago</em> by <a href="#">Peter</a>
                    </div>
                    <div class="question-inner">
                        <div class="clearfix"></div>
                        <p class="question-desc">Duis dapibus aliquam mi, eget euismod sem scelerisque ut. Vivamus at elit quis urna adipiscing iaculis. Curabitur vitae velit in neque dictum blandit. Proin in iaculis neque. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Curabitur vitae velit in neque dictum blandit.</p>
                        
                            
                        
                        
                        
                        
                            
                        
                        <div class="clearfix"></div>
                    </div>
                </article>
                <a href="#" class="load-questions"><i class="icon-refresh"></i>Load More Questions</a>
            </div>
        </div>
    </div><!-- End page-content -->

    
    <?php $__env->startSection('sidebar'); ?>
        
            
            
                
                    
                    
                    
                
                
                    
                    
                    
                
            
        

        ##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
    <?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.2-columns', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>