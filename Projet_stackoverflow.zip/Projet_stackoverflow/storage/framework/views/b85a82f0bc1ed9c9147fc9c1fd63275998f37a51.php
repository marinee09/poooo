
    
        
            
                
                    
                
                    
                
            
        
        
            
                
                
            
        
    

<header id="header">
    <section class="container clearfix">
        <div class="logo">
            <a href="<?php echo e(url('/')); ?>" class="font26">
                <span>Exchange</span>.Simplon
            </a>
        </div>
        <nav class="navigation">
            <ul>
                <li class="current_page_item">
                    <a href="<?php echo e(url('/')); ?>">Accueil</a>
                </li>
                <li>
                    <a href="<?php echo e(url('/poser-une-question')); ?>">Poser une question</a>
                </li>
                <li>
                    <a href="<?php echo e(url('/questions')); ?>">Questions</a>
                </li>
                <li>
                    <a href="<?php echo e(url('/login')); ?>">Login</a>
                </li>
            </ul>
        </nav>
    </section><!-- End container -->
</header><!-- End header -->